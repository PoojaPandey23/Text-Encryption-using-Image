package com.example.text_encryption_using_image;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class DecryptionActivity extends AppCompatActivity {

    public final static String MESSAGE_KEY ="com.example.text_encryption_using_image.message_key";
    private EditText EnterKey;
    private Button SelectImage;
    private ImageView imageView;
    private Button Decrypt;

    Bitmap bmpImage,bmpImage2;
    private static final int PICK_IMAGE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decryption);

        EnterKey = (EditText)findViewById(R.id.etEnterKey);;
        SelectImage = (Button)findViewById(R.id.btnSelectImage);
        imageView  = (ImageView)findViewById(R.id.ivImage);
        Decrypt = (Button)findViewById(R.id.btnDecrypt);

        SelectImage.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                openDecGallery();
            }
        });

        Decrypt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                bmpImage2.compress(Bitmap.CompressFormat.PNG, 100, bStream);
                byte[] byteArray = bStream.toByteArray();
                String deckey= EnterKey.getText().toString();
                if (deckey.length() == 0)
                {
                    Toast.makeText(DecryptionActivity.this, "Key is compulsory",
                            Toast.LENGTH_LONG).show();
                } else {

                    Intent intent = new Intent(DecryptionActivity.this, DecryptActivity.class);
                    intent.putExtra("decimage", byteArray);

                    intent.putExtra("key", EnterKey.getText().toString());
                    startActivity(intent);
                }
            }
        });



    }

    private void openDecGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
    }



    public void onActivityResult(final int requestCode, final int resultCode, final Intent data) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                if (resultCode == RESULT_OK) {
                    if (requestCode == PICK_IMAGE) {
                        // Get the url from data
                        final Uri selectedImageUri = data.getData();
                        if (null != selectedImageUri) {
                            // Get the path from the Uri

                            //Log.i(TAG, "Image Path : " + path);
                            // Set the image in ImageView
                            findViewById(R.id.ivImage).post(new Runnable() {
                                @Override
                                public void run() {


                                    // String sFilePath = getRealPathFromURI(selectedImageUri);
                                    ((ImageView) findViewById(R.id.ivImage)).setImageURI(selectedImageUri);
                                    imageView.buildDrawingCache();
                                    bmpImage = imageView.getDrawingCache();
                                    bmpImage2=bmpImage;
                                    if(bmpImage!=null)
                                    {
                                        Toast.makeText(DecryptionActivity.this, "Image Selected Successfully Selected For Decryption ",
                                                Toast.LENGTH_LONG).show();
                                    }

                                }
                            });

                        }
                    }
                }
            }
        }).start();

    }


//get real path from uri

    public String getPathFromURI(Uri contentUri) {
        String resa = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            resa = cursor.getString(column_index);
        }
        cursor.close();
        return resa;
    }

}
