package com.example.text_encryption_using_image;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

public class EncryptionActivity extends AppCompatActivity {

    private EditText WriteText;
    //  private EditText ImageName;
    private Button SelectImage;
    private ImageView imageView;
    private Button EncryptBtn;
    Bitmap bmpImage,bmpImage2;
    private static final int PICK_IMAGE = 100;
    // Uri imageUri;
    ByteArrayOutputStream bytearrayoutputstream;
    File file;
    FileOutputStream fileoutputstream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encryption);

        WriteText=(EditText)findViewById(R.id.etWriteText);
        // ImageName=(EditText)findViewById(R.id.etImageName);

        imageView  = (ImageView)findViewById(R.id.ivImage);
        SelectImage = (Button)findViewById(R.id.btnSelectImage);
        EncryptBtn = (Button)findViewById(R.id.btnEncrypt);

        SelectImage.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                openGallery();
            }
        });
        bytearrayoutputstream = new ByteArrayOutputStream();


// save image after encryption

        EncryptBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //do call encription here............
                if(bmpImage == null) {
                    Toast.makeText(EncryptionActivity.this, "No image selected, cannot encode",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                if(WriteText.getText().length() < 1) {
                    Toast.makeText(EncryptionActivity.this, "No secret message, cannot encode",
                            Toast.LENGTH_SHORT).show();
                    return;
                }


                try{

                    // get unique random key
                    String getkey=RandomString.getMyKey();

                    // encrypt message with key using AES algorithm
                    String msg=AESEnDecryption.encryptStrAndToBase64(getkey,getkey,WriteText.getText().toString());



                    // text encoded within image using stenography
                    bmpImage = Steganography.encode(bmpImage, msg);

                    // send new encoded image to encryption page..

                    bmpImage2=bmpImage;
                    ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                    bmpImage2.compress(Bitmap.CompressFormat.PNG, 100, bStream);
                    byte[] byteArray = bStream.toByteArray();
                    Intent intent = new Intent(EncryptionActivity.this, EncryptActivity.class);
                    intent.putExtra("encryptimage", byteArray);
                    intent.putExtra("enckey",getkey);
                    startActivity(intent);


                }catch(Exception ex){
                    Toast.makeText(EncryptionActivity.this, "Unable to encode your message with the image",
                            Toast.LENGTH_LONG).show();
                }


            }


        });


    }

    private void openGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
    }

    public void onActivityResult(final int requestCode, final int resultCode, final Intent data) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                if (resultCode == RESULT_OK) {
                    if (requestCode == PICK_IMAGE) {
                        // Get the url from data
                        final Uri selectedImageUri = data.getData();
                        if (null != selectedImageUri) {
                            // Get the path from the Uri
                            String path = getPathFromURI(selectedImageUri);
                            if(path!=null)
                            {
                                Toast.makeText(EncryptionActivity.this, path,
                                        Toast.LENGTH_LONG).show();
                            }
                            //Log.i(TAG, "Image Path : " + path);
                            // Set the image in ImageView
                            findViewById(R.id.ivImage).post(new Runnable() {
                                @Override
                                public void run() {


                                    // String sFilePath = getRealPathFromURI(selectedImageUri);
                                    ((ImageView) findViewById(R.id.ivImage)).setImageURI(selectedImageUri);
                                    imageView.buildDrawingCache();
                                    bmpImage = imageView.getDrawingCache();

                                    if(bmpImage!=null)
                                    {
                                        Toast.makeText(EncryptionActivity.this, "Image selected for encryption",
                                                Toast.LENGTH_LONG).show();
                                    }

                                }
                            });

                        }
                    }
                }
            }
        }).start();

    }

    public String getImgPath(Uri uri) {
        String[] largeFileProjection = { MediaStore.Images.ImageColumns._ID,
                MediaStore.Images.ImageColumns.DATA };
        String largeFileSort = MediaStore.Images.ImageColumns._ID + " DESC";
        Cursor myCursor = this.managedQuery(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                largeFileProjection, null, null, largeFileSort);
        String largeImagePath = "";
        try {
            myCursor.moveToFirst();
            largeImagePath = myCursor
                    .getString(myCursor
                            .getColumnIndexOrThrow(MediaStore.Images.ImageColumns.DATA));
        } finally {
            myCursor.close();
        }
        return largeImagePath;
    }

    public String getPathFromURI(Uri contentUri) {
        String resa = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            resa = cursor.getString(column_index);
        }
        cursor.close();
        return resa;
    }

    // gets the actual file path from a Uri object
    private String getRealPathFromURI(Uri contentURI) {
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        cursor.moveToFirst();
        int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
        return cursor.getString(idx);
    }


}
