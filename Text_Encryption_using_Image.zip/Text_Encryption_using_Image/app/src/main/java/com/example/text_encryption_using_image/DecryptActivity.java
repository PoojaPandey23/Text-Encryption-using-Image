package com.example.text_encryption_using_image;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DecryptActivity extends AppCompatActivity {

    Bitmap bmpImage,bmpImage2;
    private TextView WriteText;
    //  private EditText ImageName;
    private Button SelectImage;
    private ImageView imageView;
    private Button BackOption;
    public static String text_code_string;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decrypt);

        String myKey=getIntent().getStringExtra("key");
        byte[] byteArray = getIntent().getByteArrayExtra("decimage");
        bmpImage = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        WriteText=(TextView)findViewById(R.id.tvBlank);
        BackOption = (Button) findViewById(R.id.btnBackToOption);
        imageView  = (ImageView)findViewById(R.id.ivImage);
        getDecrypteddata(bmpImage,myKey);


        BackOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DecryptActivity.this, OptionActivity.class);

                startActivity(intent);

            }


        });
    }

    public void getDecrypteddata(Bitmap bmimg,String myKeyData)
    {
        if(bmpImage == null) {
            Toast.makeText(getBaseContext(), "No image selected, cannot decode",
                    Toast.LENGTH_SHORT).show();
            return;
        }


        try{
            String decodedMsg = Steganography.decode(bmpImage);
            String fnDecodedMsg=AESEnDecryption.decryptStrAndFromBase64(myKeyData,myKeyData,decodedMsg);
            text_code_string=decodedMsg;
            if(decodedMsg == null || decodedMsg.length() < 1) {
                imageView.setImageBitmap(bmpImage);
                Toast.makeText(getBaseContext(), "There was no message encoded in the image",
                        Toast.LENGTH_SHORT).show();
                return;
            } else {
                WriteText.setText(fnDecodedMsg);
                imageView.setImageBitmap(bmpImage);
                Toast.makeText(getBaseContext(), "Secret decrypted from image!",
                        Toast.LENGTH_SHORT).show();
            }

        }catch(Exception ex){
            Toast.makeText(DecryptActivity.this, "Unable to encode your message with the image",
                    Toast.LENGTH_LONG).show();

            Intent intent = new Intent(DecryptActivity.this, DecryptionActivity.class);
            startActivity(intent);
        }


    }
}
