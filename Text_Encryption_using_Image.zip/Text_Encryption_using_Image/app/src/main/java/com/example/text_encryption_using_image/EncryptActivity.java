package com.example.text_encryption_using_image;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EncryptActivity extends AppCompatActivity {

    Bitmap bmpImage, bmpImage2;
    private TextView YourKeyIs;
    private TextView Key;
    private ImageView imageView;
    private Button SaveImage;
    private Button SendImage;
    private Button BackOption;

    ByteArrayOutputStream bytearrayoutputstream;
    File file;
    FileOutputStream fileoutputstream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encrypt);

        byte[] byteArray = getIntent().getByteArrayExtra("encryptimage");
        bmpImage = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);

        YourKeyIs=(TextView)findViewById(R.id.tvYourKeyIs);
        Key=(TextView)findViewById(R.id.tvKey);
        Key.setTextIsSelectable(true);
        SaveImage = (Button) findViewById(R.id.btnSaveImage);
        BackOption = (Button) findViewById(R.id.btnBackToOption);
        imageView = (ImageView) findViewById(R.id.ivImage);

        String myKey=getIntent().getStringExtra("enckey");

        bytearrayoutputstream = new ByteArrayOutputStream();
        imageView.setImageBitmap(bmpImage);
        Key.setText(myKey);

        SaveImage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                saveEncryptedImage(bmpImage);
            }

        });

        BackOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EncryptActivity.this, OptionActivity.class);

                startActivity(intent);

            }


        });

    }

    public void saveEncryptedImage(Bitmap bmimg)
    {
        if (bmimg == null) {
            Toast.makeText(getBaseContext(), "No image selected, unable to save data",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        OutputStream fOut = null;

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.US);
        Date now = new Date();
        String fileName = formatter.format(now);

        File path = getExternalFilesDir(Environment.DIRECTORY_PICTURES);

        File file = new File(path, "kec" + fileName + ".png");

        try {


            fOut = new FileOutputStream(file);

            bmimg.compress(Bitmap.CompressFormat.PNG, 100, fOut);
            fOut.flush();
            fOut.close();


            //MediaStore.Images.Media.insertImage(getContentResolver(), bmpImage2, "a"+enc_img_name.getText().toString(), null);
            //MediaStore.Images.Media.insertImage(getContentResolver(), Environment.getExternalStorageDirectory()+"/a"+enc_img_name.getText().toString(), "abc", null);
            Toast.makeText(EncryptActivity.this, "Secret message encoded  image saved successfully",
                    Toast.LENGTH_LONG).show();


        }
        catch (Exception ex)
        {
            Toast.makeText(EncryptActivity.this, "Failed to save Image",
                    Toast.LENGTH_LONG).show();
            // System.out.println(ex.getMessage());
        }
    }
}
