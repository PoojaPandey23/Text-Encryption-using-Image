package com.example.text_encryption_using_image;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class OptionActivity extends AppCompatActivity {

    private TextView ChooseOption;
    private Button Encryption;
    private Button Decryption;
    private Button Exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option);

        ChooseOption = (TextView) findViewById(R.id.tvChooseOption);
        Encryption = (Button) findViewById(R.id.btnEncryption);
        Decryption = (Button) findViewById(R.id.btnDecryption);
        Exit = (Button) findViewById(R.id.btnExit);

        Encryption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OptionActivity.this, EncryptionActivity.class);
                startActivity(intent);

            }


        });
        Decryption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OptionActivity.this, DecryptionActivity.class);
                startActivity(intent);

            }


        });

        Exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OptionActivity.this, MainActivity.class);
                startActivity(intent);

            }


        });


    }
}
