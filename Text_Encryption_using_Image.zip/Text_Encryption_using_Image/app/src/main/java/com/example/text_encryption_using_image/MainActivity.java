package com.example.text_encryption_using_image;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView WelcometoourApp;
    private TextView TextEncryptionusingImage;
    private Button SignIn;
    private TextView NewUser;
    private Button Register;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WelcometoourApp = (TextView)findViewById(R.id.tvWTOA);
        TextEncryptionusingImage = (TextView)findViewById(R.id.tvTEUI);
        SignIn = (Button)findViewById(R.id.btnSignIn);
        NewUser = (TextView)findViewById(R.id.tvNewUser);
        Register = (Button)findViewById(R.id.btnRegister);

        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);

                startActivity(intent);

            }


        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);

                startActivity(intent);

            }


        });

    }
}
