package com.example.text_encryption_using_image;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    private EditText UserName;
    private EditText Password;
    private EditText ConfirmPassword;
    private Button Register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        databaseHelper = new DatabaseHelper(this);
        UserName = (EditText) findViewById(R.id.etUserName);
        Password = (EditText) findViewById(R.id.etPassword);
        ConfirmPassword = (EditText) findViewById(R.id.etConfirmPassword); // confirm
        Register = (Button) findViewById(R.id.btnRegister);

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(UserName.getText().toString() == null || UserName.getText().toString()=="") {
                    Toast.makeText(RegisterActivity.this, "Username cannot be empty",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                if(Password.getText().toString() == null || Password.getText().toString()=="") {
                    Toast.makeText(RegisterActivity.this, "Password cannot be empty",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                //  Toast.makeText(RegisterActivity.this, "User Registered Successfully"+ NewPassword.getText().toString(), Toast.LENGTH_LONG).show();
                boolean isInserted= databaseHelper.registerData(UserName.getText().toString(), Password.getText().toString(), ConfirmPassword.getText().toString());
                // Toast.makeText(RegisterActivity.this, "User Registered Successfully", Toast.LENGTH_LONG).show();

                if(isInserted == true)
                {
                    Toast.makeText(RegisterActivity.this, "User Registered Successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(RegisterActivity.this, "User Registration Failed", Toast.LENGTH_LONG).show();

                }

                // Toast.makeText(RegisterActivity.this, "User registered Successfully", Toast.LENGTH_LONG).show();

            }


        });


    }
}
