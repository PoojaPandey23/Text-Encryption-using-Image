package com.example.text_encryption_using_image;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    DatabaseHelper databaseHelper;
    private EditText UserName;
    private EditText Password;
    private Button Login;
    private TextView NOAR;

    private int counter=5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        UserName = (EditText)findViewById(R.id.etUserName);
        Password = (EditText)findViewById(R.id.etPassword);
        Login = (Button)findViewById(R.id.btnLogin);
        NOAR = (TextView)findViewById(R.id.tvNoar);

        NOAR.setText("No of attempts remaining: 5");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = UserName.getText().toString().trim();
                String pwd = Password.getText().toString().trim();
                Boolean res = databaseHelper.checkUser(user, pwd);
                if(res == true)
                {
                    Intent intent = new Intent(LoginActivity.this,OptionActivity.class);
                    startActivity(intent);
                }
                else
                {
                    counter--;
                    Toast.makeText(LoginActivity.this, "Login Failed, No of attempts remaining: " + String.valueOf(counter), Toast.LENGTH_LONG).show();

                    if(counter == 0){
                        Login.setEnabled(false);
                    }

                }
            }


        });

    }
}
