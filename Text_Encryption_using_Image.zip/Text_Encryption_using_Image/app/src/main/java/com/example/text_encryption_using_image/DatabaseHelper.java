package com.example.text_encryption_using_image;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "MyDataBase";
    public static final String REGISTER_TABLE = "UserRegistration";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "UserName";
    public static final String COL_3 = "NewPassword";
    public static final String COL_4 = "ConfirmPassword";


    //constructor
    public DatabaseHelper(Context context) {

        super(context, DATABASE_NAME, null, 1 );
    }

    // public SQLiteDatabase getWritetableDatabase() {
    // }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS "+REGISTER_TABLE);
        db.execSQL("CREATE TABLE " + DatabaseHelper.REGISTER_TABLE +" (" + DatabaseHelper.COL_1 +" INTEGER PRIMARY KEY AUTOINCREMENT," + DatabaseHelper.COL_2 +" VARCHAR, " + DatabaseHelper.COL_3 +" VARCHAR ," + DatabaseHelper.COL_4 +" VARCHAR)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS "+REGISTER_TABLE);
        onCreate(db);

    }

    public boolean registerData(String userName,String password,String confirmPassword) {
        //Toast.makeText(RegisterActivity.this, "User Registration Failed", Toast.LENGTH_LONG).show();
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,userName);
        contentValues.put(COL_3,password);
        contentValues.put(COL_4,confirmPassword);

        long result;
        result = db.insert(REGISTER_TABLE, null, contentValues);
        //  db.close();
        //return true;

        if(result == -1)
            return false;
        else
            return true;
    }

    public boolean checkUser(String username, String password){
        String[] columns = { DatabaseHelper.COL_1 };
        SQLiteDatabase db = getReadableDatabase();
        String selection = DatabaseHelper.COL_2 + "=?" + " and " + DatabaseHelper.COL_3 + "=?";
        String[] selectionArgs = { username, password };
        Cursor cursor;
        cursor = db.query(DatabaseHelper.REGISTER_TABLE,columns,selection,selectionArgs,null,null,null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        if(count>0)
            return  true;
        else
            return  false;
    }
}




